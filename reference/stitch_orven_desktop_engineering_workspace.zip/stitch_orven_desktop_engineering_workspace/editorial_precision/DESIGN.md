---
name: Editorial Precision
colors:
  surface: '#f9f9f8'
  surface-dim: '#dadad9'
  surface-bright: '#f9f9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f3'
  surface-container: '#eeeeed'
  surface-container-high: '#e8e8e7'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#46464b'
  inverse-surface: '#2f3130'
  inverse-on-surface: '#f1f1f0'
  outline: '#76777b'
  outline-variant: '#c7c6cb'
  surface-tint: '#5e5e62'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1f'
  on-primary-container: '#848387'
  inverse-primary: '#c7c6ca'
  secondary: '#2252ca'
  on-secondary: '#ffffff'
  secondary-container: '#426ce5'
  on-secondary-container: '#fefbff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002110'
  on-tertiary-container: '#399464'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e3e2e6'
  primary-fixed-dim: '#c7c6ca'
  on-primary-fixed: '#1b1b1f'
  on-primary-fixed-variant: '#46464a'
  secondary-fixed: '#dce1ff'
  secondary-fixed-dim: '#b5c4ff'
  on-secondary-fixed: '#00164d'
  on-secondary-fixed-variant: '#003cac'
  tertiary-fixed: '#9bf6be'
  tertiary-fixed-dim: '#7fd9a3'
  on-tertiary-fixed: '#002110'
  on-tertiary-fixed-variant: '#005230'
  background: '#f9f9f8'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  headline-xl:
    fontFamily: Newsreader
    fontSize: 30px
    fontWeight: '400'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 22px
    fontWeight: '400'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Geist
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.01em
  body-editorial:
    fontFamily: Newsreader
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-default:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 19px
    letterSpacing: -0.005em
  body-strong:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 19px
    letterSpacing: -0.005em
  caption-ui:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 15px
    letterSpacing: 0.01em
  code-inline:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 17px
    letterSpacing: -0.02em
  code-block:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: -0.02em
  label-keybinding:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.02em
  label-data-metric:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.375rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system fuses the intellectual poise of high-end editorial broadsheets with the unyielding rigor of an industrial-grade systems engineering cockpit. Designed specifically for native desktop execution via Rust and Tauri, the environment treats static analysis, code security auditing, and AST inspection not as chaotic stream logs, but as definitive, archival-grade documents.

### Personality & Values
- **Archival Authority**: Information is presented as permanent, verifiable evidence. Data displays mimic heavy archival paper, precision ruling, and typographic clarity over transient web trends.
- **Instrumental Restraint**: Chrome recedes entirely. The interface eschews gratuitous gradients, floating glass bubbles, and generic rounded containers. Decoration is eliminated in favor of information density and typographic tension.
- **Keyboard-Driven Sovereignty**: Engineered for instant execution. Every piece of telemetry, finding, or AST node can be navigated, copied, and operated without touching a pointer device.

### Aesthetic Movement
**Editorial Precision (Modern Minimalist + Swiss Precision Monolith)**: Monolithic layout discipline structured by hairline 1px rules, strict tabular alignment, and an intentional interplay between high-clarity neutral grotesks, literary editorial serifs for analytical narratives, and dense monospace notation for machine execution states.

## Colors

The system uses a warm, low-glare paper substrate (`#FBFBFA`) accented by razor-sharp slate ink. Color is never employed for decorative flair; it is strictly an epistemological signal for state, telemetry, and engineering severity.

### Surface Canvas Hierarchy (Light Mode)
- **Canvas Base**: `#FBFBFA` — Root window background, traffic-light chrome, and primary split gutters.
- **Surface Sunk / Recessed**: `#F5F5F3` — Rail navigation, terminal trays, and AST inspect drawers.
- **Surface Elevated / Paper**: `#FFFFFF` — Editor sheets, audit reports, and active workspace document panes.
- **Hairline Dividing Rules**: `#EAEAE7` (primary partition), `#DFDFDC` (active pane boundary, high-precision contrast).

### Ink & Typography Palette (Light Mode)
- **Ink Primary**: `#111215` — Headings, severity tallies, active code statements, primary focus tokens.
- **Ink Secondary**: `#373A40` — Body narratives, analysis text, parameter keys.
- **Ink Muted / Metadata**: `#6C707A` — Line numbers, file paths, keyboard hints, passive rule labels.
- **Ink Subtle**: `#9FA3AC` — Inactive breadcrumbs, disabled shortcuts, placeholder rules.

### Semantic Telemetry States
- **Verified / Safe**:
  - Ink: `#16794C`
  - Fill / Substrate: `#EBF7EE`
  - Border Hairline: `#C4E8CE`
- **High Severity / Vulnerability**:
  - Ink: `#D9383A`
  - Fill / Substrate: `#FDF2F2`
  - Border Hairline: `#F8D0D1`
- **Warning / Missing Evidence / Assumption**:
  - Ink: `#D97706`
  - Fill / Substrate: `#FEF8EC`
  - Border Hairline: `#FBE2B5`
- **Daemon / Protocol / MCP Active**:
  - Ink: `#3B66DE`
  - Fill / Substrate: `#EEF2FD`
  - Border Hairline: `#CCD7F8`

### Secondary Dark Mode Counterparts
When switched into dark mode, the philosophy flips to a low-luminance deep obsidian slab:
- **Canvas Base**: `#0E0F12`
- **Surface Sunk**: `#090A0C`
- **Surface Paper**: `#14151A`
- **Dividing Rules**: `#22242B` / `#2D3039`
- **Ink Primary**: `#F1F2F5`
- **Ink Secondary**: `#B4B8C4`
- **Ink Muted**: `#6E7382`
- **Semantic Fills**: Shift to 12% alpha variants of light-mode ink tones over `#14151A`.

## Typography

Typography establishes tension between the cerebral, long-form analytical prose of security reports and the exact machine notation of compilation artifacts.

### The Tri-Font Structural System
1. **Geist**: Native UI chrome, panel headers, settings, table headers, and operational controls. Unobtrusive, neutral, engineered for high-density legibility on Retina screens.
2. **Newsreader**: The editorial voice. Used exclusively for long-form narrative findings, vulnerability executive summaries, and systemic impact retrospectives. It grants engineering audits the weight of authoritative print journalism.
3. **JetBrains Mono**: Machine artifacts, byte offsets, AST expressions, file hashes, commit IDs, and keyboard chords (`⌘K`, `⇧⌘B`). Set with deliberate line-height parity to align line numbers perfectly with source code inspection panes.

### Typographic Rules
- Use `font-variant-numeric: tabular-nums lining-nums` across all `JetBrains Mono` and table figures to eliminate layout jitter during high-frequency Rust telemetry updates.
- Section titles in editorial views never drop below a line-height multiplier of 1.35 to preserve readability across large desktop windows.

## Layout & Spacing

The workspace uses a column-and-drawer desktop docking grid tailored for multi-pane engineering workstations, prioritizing dense spatial conservation over web-like breathing room.

### Window Geometry & Grid Architecture
- **Titlebar Chrome**: 38px fixed height with macOS-native window controls left-aligned (traffic lights inset at `x: 14px, y: 12px`). The titlebar integrates the active workspace breadcrumb, active target binary, and the daemon heartbeat chip.
- **Tauri Multi-Pane Paneling**:
  - **Left Rail (Index / Workspace)**: Collapsible, default 240px width, min 180px, max 360px.
  - **Primary Core (Editor / Audit Sheet)**: Fluid grid column, min 540px.
  - **Context Inspector (AST / Metadata / MCP Inspector)**: Collapsible, default 340px width, min 280px, max 480px.
  - **Bottom Terminal / Diagnostics Drawers**: Collapsible, 160px default height, min 96px, max 400px.

### Breakpoint Matrix (Desktop Display Focus)
- **Compact Window (`< 980px`)**: The context inspector auto-collapses into an overlay slide-out; primary editor consumes full remaining width.
- **Standard Desktop (`980px – 1440px`)**: 3-pane default layout: Left Rail (240px) + Fluid Core + Context Inspector (320px).
- **Ultrawide / Dual Inspect (`> 1440px`)**: Core view splits into twin side-by-side editorial panes for direct source-to-AST diffing.

### Spacing Rules
- Never use padding greater than `space-md` inside active engineering tables, tree items, or code lists.
- Vertical division between panes uses a 1px solid hairline (`#EAEAE7`) rather than empty whitespace gaps.

## Elevation & Depth

This design system deliberately rejects heavy drop shadows, blurred ambient glow, and skeuomorphic bevels. Elevation is achieved through **tonal planar layering** and **hairline edge definition**.

### Plane Architecture
- **Level 0 (Canvas Floor - `#FBFBFA`)**: Structural window background and inactive rail surfaces.
- **Level 1 (Paper Pane - `#FFFFFF`)**: Document surfaces, source code viewers, and editable sheets. Differentiated strictly by a 1px boundary (`#EAEAE7`), without box-shadow.
- **Level 2 (Command Palette & Modal Dialogs)**: Overlaid floating utilities (e.g., Quick Switcher `⌘K`, AST search).
  - Background: `#FFFFFF`
  - Outline: 1px solid `#DFDFDC`
  - Shadow: `0px 8px 24px -4px rgba(17, 18, 21, 0.06), 0px 2px 6px -1px rgba(17, 18, 21, 0.03)`
- **Level 3 (HUD Tooltips & Hover Diagnostics)**:
  - Background: `#111215` (Light mode inversion)
  - Color: `#FBFBFA`
  - Border: 1px solid rgba(255, 255, 255, 0.08)
  - Shadow: `0px 4px 12px rgba(0, 0, 0, 0.12)`

### Visual Boundaries
Every split container, dock, and table row relies on exact 1px lines (`#EAEAE7`). The bottom border of tabular rows serves as an anchor, creating an authentic ledger-like aesthetic.

## Shapes

The geometry reflects surgical desktop tools: compact, disciplined, and slightly softened to harmonise with macOS window curvature without drifting into bubbly consumer software tropes.

### Geometry Specifications
- **Interactive Controls (Buttons, Inputs, Selects)**: Soft `4px` (`0.25rem`) border radius.
- **Code Tokens & In-line Badges**: `3px` radius for tight, unclipped baseline alignment with mono fonts.
- **Command Overlays & Modals**: `8px` (`0.5rem`) outer radius with `1px` crisp hairline enclosure.
- **Application Window Frame**: Matches native macOS window curvature (`10px` or system standard).
- **Dividers & Split Handles**: Strictly rectangular (`0px`), continuous hairlines spanning 100% of parent height/width.

## Components

### Buttons & Interactive Triggers
- **Primary Action (Commit / Run Audit)**:
  - Background: `#111215`, Color: `#FFFFFF`
  - Typography: `Geist 12px / 500 weight`
  - Padding: `4px 10px` (ultra-dense native macOS feel)
  - Border: None. Active state: `#24262C`
- **Secondary / Ghost Action**:
  - Background: `transparent`, Color: `#373A40`
  - Border: 1px solid `#DFDFDC`
  - Hover: Background `#F5F5F3`, Color: `#111215`
- **Keyboard Shortcut Display**: Attached inline to buttons using `label-keybinding` tokens in `#6C707A` with an internal `3px` padded capsule.

### Status Badges & Chips
- **Semantic Finding Badges (e.g., Safe, Vulnerable, Warning)**:
  - Border radius: `3px`
  - Padding: `2px 6px`
  - Typography: `JetBrains Mono 11px / 600 weight`
  - Style: Subtle semantic background with high-contrast text and a hairline matching border (e.g., Critical: bg `#FDF2F2`, text `#D9383A`, border `#F8D0D1`).
  - No icons unless communicating active processing spin or verified state checks.

### Input Fields & Search Bars
- **Inline Filter / Query Bar**:
  - Background: `#FFFFFF`
  - Border: 1px solid `#DFDFDC`
  - Focus Ring: No thick outer glow; transitions to 1px solid `#111215`
  - Text: `Geist 12px`, with placeholder text in `#9FA3AC`
  - Height: `26px` compact native scale.

### Lists & Engineering Ledgers
- **Tree Views & Finding Ledgers**:
  - Row height: Fixed `24px` for code symbols and file trees; `32px` for vulnerability report lists.
  - Hover State: `#F5F5F3` full row bleed.
  - Selected / Active State: `#EAEAE7` background with a left-edge indicator (`2px` solid `#111215`).
  - Dividers: Single bottom hairline `#EAEAE7`.

### Checkboxes & Toggle Controls
- **Checkboxes**:
  - Dimension: `13px x 13px` square with `2px` roundedness.
  - Unchecked: `#FFFFFF` fill with `1px solid #DFDFDC`.
  - Checked: `#111215` fill with white `#FFFFFF` crisp check glyph.
- **Toggles**: Avoid round switch toggles; use segmented two-state inline pill buttons (`[AST] [RAW]`) with 1px borders.

### Cards & Container Panels
- Cards as decorative floating containers are **forbidden**.
- Containers are represented strictly as bordered panes: continuous vertical and horizontal borders dividing the screen, with optional sticky header bars (`28px` height, background `#F5F5F3`, border-bottom `1px solid #EAEAE7`).

### Command Palette (`⌘K`)
- Center-anchored desktop modal, `580px` wide.
- Flat white surface `#FFFFFF`, crisp hairline border `#DFDFDC`, subtle elevation shadow Level 2.
- Instant keyboard navigation: arrows cycle items with a `#F5F5F3` selection highlight and right-aligned shortcut indicators.